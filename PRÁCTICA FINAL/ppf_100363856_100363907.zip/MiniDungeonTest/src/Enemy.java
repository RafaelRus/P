
public class Enemy {

	//CARACTER�STICAS DEL ENEMIGO
	private int id;
	private int type;
	private int x;
	private int y;
	private int health;
	private int damage;
	private String spriteFileName;
	
	
	
	public Enemy(int id, int type) {
		//M�TODO PARA IDENTIFICAR EL TIPO DE ENEMIGO
		//CADA TIPO TENDR� UNA VIDA DISTINTA Y CAUSAR� AL JUGADOR DIFERENTE DA�O
		this.id = id;
		this.type= type;
		switch(type) {
			case 0:
			//ENEMIGO 1
			setSpriteFileName("black-rook.png");
			setHealth(1);
			setDamage(10);
			break;
			
			case 1:
			//ENEMIGO 2
			setSpriteFileName("black-knight.png");
			setHealth(2);
			setDamage(20);
			break;
			
			case 2:
			//ENEMIGO 3
			setSpriteFileName("black-bishop.png");
			setHealth(3);
			setDamage(30);
			break;
			
			case 3:
			//ENEMIGO FINAL
			setSpriteFileName("green-queen.png");
			setHealth(4);
			setDamage(40);
			break;
		}
	}
	
	
	public void print() {
		//IMPRIMIR LOS ENEMIGOS, SU ID Y SU TIPO (EN CASO DE QUE EL JUGADOR QUIERA SABER SU POSICI�N EXACTA)
		System.out.println("Enemy: " + id + ", " + x + ", " + y + ", " + type);
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	
	
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		this.health = health;
	}
	
	
	public int getDamage() {
		return damage;
	}
	public void setDamage(int damage) {
		this.damage = damage;
	}
	
	
	public String getSpriteFileName() {
		return spriteFileName;
	}
	public void setSpriteFileName(String spriteFileName) {
		this.spriteFileName = spriteFileName;
	}
}
