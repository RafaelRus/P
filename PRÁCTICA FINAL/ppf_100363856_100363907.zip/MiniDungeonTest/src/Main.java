
import minidungeon.MiniDungeonGUI;


//PARA INTRODUCIR NOMBRE
import javax.swing.JOptionPane;


public class Main {
	public static void pintarPiso (int floorCurrent, MiniDungeonGUI minidungeon, Floor[] dungeon) {
		//ESTE M�TODO PINTAR� UN NUEVO PISO CADA VEZ QUE SUBA EL JUGADOR DE PISO
		
		
		//PINTAR EL PISO
		for (int i = 0; i < dungeon[floorCurrent].floor.length; i++) {
			for (int j = 0; j < dungeon[floorCurrent].floor[i].length; j++) {
				minidungeon.md_setSquareColor(i, j, dungeon[floorCurrent].floor[i][j].getRed(), dungeon[floorCurrent].floor[i][j].getGreen(), dungeon[floorCurrent].floor[i][j].getBlue());
			}
		}
		
		
		//JUGADOR VISIBLE
		boolean squareValid = false;
		int xPlayer = 0;
		int yPlayer = 0;
		minidungeon.md_addSprite(999, "red-pawn.png", true);
		
		while (squareValid == false) {
			xPlayer = (int) (Math.random() * Constants.getAncho());
			yPlayer = (int) (Math.random() * Constants.getAlto());
			if (dungeon[floorCurrent].floor[xPlayer][yPlayer].getCasilla() != 0) {
				for (int i = 0; i < Constants.getEnemies(); i++) {
					if (dungeon[floorCurrent].enemies[i].getX() == xPlayer && dungeon[floorCurrent].enemies[i].getY() == yPlayer) {
						squareValid = false;
					}
					else {
						for (int j = 0; j < Constants.getObjects(); j++) {
							if (dungeon[floorCurrent].objects[j].getX() == xPlayer && dungeon[floorCurrent].objects[j].getY() == yPlayer) {
								squareValid = false;
							}
							else {
								squareValid = true;
							}
						}
					}
				}
			}
		}
	    minidungeon.md_moveSprite(999, xPlayer, yPlayer);
	    minidungeon.md_setSpriteVisible(999, true);	
		
	    
		//OBJETOS VISIBLES
		for (int i = 0; i < Constants.getObjects(); i++) {
			if (dungeon[floorCurrent].objects[i] != null) {
				minidungeon.md_addSprite(dungeon[floorCurrent].objects[i].getId(), dungeon[floorCurrent].objects[i].getSpriteFileName(), true);
				minidungeon.md_moveSprite(dungeon[floorCurrent].objects[i].getId(), dungeon[floorCurrent].objects[i].getX(), dungeon[floorCurrent].objects[i].getY());
				minidungeon.md_setSpriteVisible(dungeon[floorCurrent].objects[i].getId(), true);
			}
		}
		
		
		//ENEMIGOS VISIBLES
		for (int i = 0; i < Constants.getEnemies(); i++) {
			if (dungeon[floorCurrent].enemies[i] != null) {
				minidungeon.md_addSprite(dungeon[floorCurrent].enemies[i].getId(), dungeon[floorCurrent].enemies[i].getSpriteFileName(), true);
				minidungeon.md_moveSprite(dungeon[floorCurrent].enemies[i].getId(), dungeon[floorCurrent].enemies[i].getX(), dungeon[floorCurrent].enemies[i].getY());
				minidungeon.md_setSpriteVisible(dungeon[floorCurrent].enemies[i].getId(), true);
			}
		}
		
	}
	
	public static void main(String[] args) throws InterruptedException {
		
		//NECESARIO PARA INICIAR EL JUEGO
		boolean game = false;
		boolean newGame = false;
		MiniDungeonGUI minidungeon = new MiniDungeonGUI(Constants.getAncho(), Constants.getAlto());
		//DECLARAR EL ARRAY DE PISOS
		Floor[] dungeon = new Floor[Constants.getPisos()];
		int floorCurrent = 0;
		
		
		//INICIO DEL JUEGO
		while (game == false) {
			
			if (!newGame) {
				
				dungeon[floorCurrent] = new Floor();
				
				
				//PINTAR EL PISO
				pintarPiso(floorCurrent, minidungeon, dungeon);
				
				
				//CARACTER�STICAS DEL JUGADOR
				Player player = new Player();
				minidungeon.md_setPortraitPlayer("portrait.jpg");
				minidungeon.md_setTextPlayerName(player.getName());
				minidungeon.md_setTextFood(player.getFood());
				minidungeon.md_setTextStrength(player.getStrength());
				minidungeon.md_setTextGold(player.getGold());
				minidungeon.md_setTextHealthCurrent(player.getHealth());
				minidungeon.md_setTextHealthMax(player.getHealthMax());
				minidungeon.md_setTextFloor(player.getFloor());
				
				
				//PARA HACER VISIBLE EL MINIDUNGEON
				minidungeon.setVisible(true);
				minidungeon.md_println("MiniDungeon");
				
				
				//CREACI�N INICIAL DEL JUGADOR
				boolean squareValid = false;
				int xPlayer = 0;
				int yPlayer = 0;
				minidungeon.md_addSprite(999, "red-pawn.png", true);
				while (squareValid == false) {
					//EL JUGADOR SE GENERA INICIALMENTE DE MANERA QUE NO COINCIDA EN LA MISMA POSICI�N QUE CUALQUIER ENEMIGO U OBJETO
					xPlayer = (int) (Math.random() * Constants.getAncho());
					yPlayer = (int) (Math.random() * Constants.getAlto());
					if (dungeon[floorCurrent].floor[xPlayer][yPlayer].getCasilla() != 0) {
						for (int i = 0; i < Constants.getEnemies(); i++) {
							if (dungeon[floorCurrent].enemies[i].getX() == xPlayer && dungeon[floorCurrent].enemies[i].getY() == yPlayer) {
								squareValid = false;
							}
							else {
								for (int j = 0; j < Constants.getObjects(); j++) {
									if (dungeon[floorCurrent].objects[j].getX() == xPlayer && dungeon[floorCurrent].objects[j].getY() == yPlayer) {
										squareValid = false;
									}
									else {
										squareValid = true;
									}
								}
							}
						}
					}
				}
			    minidungeon.md_moveSprite(999, xPlayer, yPlayer);
			    minidungeon.md_setSpriteVisible(999, true);	
			    
			    
			    //PARA INTRODUCIR NOMBRE
			    minidungeon.md_setTextPlayerName(JOptionPane.showInputDialog("Nombre: "));
			    
			    
			    //BUCLE INFINITO LLAMADO RUNNING
			    boolean running = true;
			    boolean freeSquare;
			    while (running == true) {
			    	freeSquare = false;
			    	
			    	
			    	//CONDICI�N DE VICTORIA
			    	if (player.getFloor() == (Constants.getPisos() + 1)) {
			    		running = false;
			    		minidungeon.md_showMessageDialog("You Win");
			    	}
			    	
			    	
			    	//CONDICI�N DE DERROTA
			    	if (player.getHealth() <= 0) {
			    		running = false;
			    		minidungeon.md_showMessageDialog("Game Over");
			    	}
			    	
			    	
			    	//NECESARIO PARA QUE EN CADA MOVIMIENTO COMPRUEBE SI HAY ENEMIGO U OBJETO
			    	Enemy checkEnemy = null;
			    	Object checkObject = null;
			    	
			    	
			    	//MOVIMIENTO DEL ENEMIGO
			    	int enemyMovement = 0;
			    	boolean squareAvailability;
			    	for (int i = 0; i < Constants.getEnemies(); i++) {
			    		//FOR QUE RECORRE TODOS LOS ENEMIGOS
			    		squareAvailability = false;
			    		if (dungeon[floorCurrent].enemies[i] != null && dungeon[floorCurrent].enemies[i].getHealth() != 0) {
			    			enemyMovement = (int) (Math.random() * 4);
			    			switch (enemyMovement) {
			    				case 0:
			    				//EL ENEMIGO SE MUEVE HACIA LA DERECHA SOLO SI EXISTE (SI TIENE VIDA)
			    				//PRIMERO COMPRUEBA QUE AL MOVERSE NO SE SALGA DEL TABLERO NI ATRAVIESE PAREDES
			    				//DESPU�S VA COMPROBANDO POCO A POCO SI CHOCA CON OTROS ENEMIGOS, CON UN OBJETO O CON EL JUGADOR
			    				if ((dungeon[floorCurrent].enemies[i].getX() + 1) < Constants.getAncho() && dungeon[floorCurrent].floor[(dungeon[floorCurrent].enemies[i].getX() + 1)][dungeon[floorCurrent].enemies[i].getY()].getCasilla() != 0) {
			    					int j = 0;
			    					while (j < Constants.getEnemies() && checkEnemy == null) {
			    						if (dungeon[floorCurrent].enemies[j].getX() == (dungeon[floorCurrent].enemies[i].getX() + 1) && dungeon[floorCurrent].enemies[j].getY() == dungeon[floorCurrent].enemies[i].getY()){
			    							checkEnemy = dungeon[floorCurrent].enemies[j];
			    							j++;
			    						}
			    						else {
			    							j++;
			    						}
			    					}
			    					if (checkEnemy != null) {
			    						//SI HAY OTRO ENEMIGO
			    						squareAvailability = false;	
			    					}
			    					else {
			    						//SI NO HAY OTRO ENEMIGO
			    						int k = 0;
			        					while (k < Constants.getObjects() && checkObject == null) {
			        						if (dungeon[floorCurrent].objects[k].getX() == (dungeon[floorCurrent].enemies[i].getX() + 1) && dungeon[floorCurrent].objects[k].getY() == dungeon[floorCurrent].enemies[i].getY()) {
			        							checkObject = dungeon[floorCurrent].objects[k];
			        							k++;
			        						}
			        						else {
			        							k++;
			        						}
			        					}
			        					if (checkObject != null) {
			        						//SI HAY UN OBJETO
			        						squareAvailability = false;
			        					}
			        					else {
			        						//SI NO HAY UN OBJETO
			        						if (xPlayer == (dungeon[floorCurrent].enemies[i].getX() + 1) && yPlayer == dungeon[floorCurrent].enemies[i].getY()) {
			        							//SI HAY JUGADOR, ATACA
			        							squareAvailability = false;
			        							player.setHealth(player.getHealth() - dungeon[floorCurrent].enemies[i].getDamage());
			        							minidungeon.md_setTextHealthCurrent(player.getHealth());
			        							minidungeon.md_animateDamage();
			        						}
			        						else {
			        							//SI NO HAY JUGADOR
			        							squareAvailability = true;
			        						}
			        					}
			        				}
			    					if (squareAvailability == true) {
			    						//SE MUEVE HACIA LA DERECHA SI NO HAY JUGADOR
			    						minidungeon.md_moveSprite(dungeon[floorCurrent].enemies[i].getId(), dungeon[floorCurrent].enemies[i].getX() + 1, dungeon[floorCurrent].enemies[i].getY());
			    					}
			    				}
			    				break;
			    				
			    				case 1:
			    				//EL ENEMIGO SE MUEVE HACIA LA IZQUIERDA SOLO SI EXISTE (SI TIENE VIDA)
			    				//PRIMERO COMPRUEBA QUE AL MOVERSE NO SE SALGA DEL TABLERO NI ATRAVIESE PAREDES
				    			//DESPU�S VA COMPROBANDO POCO A POCO SI CHOCA CON OTROS ENEMIGOS, CON UN OBJETO O CON EL JUGADOR
			    				if ((dungeon[floorCurrent].enemies[i].getX() - 1) >= 0 && dungeon[floorCurrent].floor[(dungeon[floorCurrent].enemies[i].getX() - 1)][dungeon[floorCurrent].enemies[i].getY()].getCasilla() != 0) {
				    				int j = 0;
				    				while (j < Constants.getEnemies() && checkEnemy == null) {
				    					if (dungeon[floorCurrent].enemies[j].getX() == (dungeon[floorCurrent].enemies[i].getX() - 1) && dungeon[floorCurrent].enemies[j].getY() == dungeon[floorCurrent].enemies[i].getY()){
				    						checkEnemy = dungeon[floorCurrent].enemies[j];
				    						j++;
				    					}
				    					else {
				    						j++;
				    					}
				    				}
				    				if (checkEnemy != null) {
				    					//SI HAY OTRO ENEMIGO
				    					squareAvailability = false;	
				    				}
				    				else {
				    					//SI NO HAY OTRO ENEMIGO
				    					int k = 0;
				        				while (k < Constants.getObjects() && checkObject == null) {
				        					if (dungeon[floorCurrent].objects[k].getX() == (dungeon[floorCurrent].enemies[i].getX() - 1) && dungeon[floorCurrent].objects[k].getY() == dungeon[floorCurrent].enemies[i].getY()) {
				        						checkObject = dungeon[floorCurrent].objects[k];
				        						k++;
				        					}
				        					else {
				        						k++;
				        					}
				        				}
				        				if (checkObject != null) {
				        					//SI HAY UN OBJETO
				        					squareAvailability = false;
				        				}
				        				else {
				        					//SI NO HAY UN OBJETO
				        					if (xPlayer == (dungeon[floorCurrent].enemies[i].getX() - 1) && yPlayer == dungeon[floorCurrent].enemies[i].getY()) {
				        						//SI HAY JUGADOR, ATACA
				        						squareAvailability = false;
				        						player.setHealth(player.getHealth() - dungeon[floorCurrent].enemies[i].getDamage());
				        						minidungeon.md_setTextHealthCurrent(player.getHealth());
				        						minidungeon.md_animateDamage();
				        					}
				        					else {
				        						//SI NO HAY JUGADOR
				       							squareAvailability = true;
				       						}
				        				}
				        			}
				    				if (squareAvailability == true) {
				    					//SE MUEVE HACIA LA IZQUIERDA SI NO HAY JUGADOR
				    					minidungeon.md_moveSprite(dungeon[floorCurrent].enemies[i].getId(), dungeon[floorCurrent].enemies[i].getX() - 1, dungeon[floorCurrent].enemies[i].getY());
				    				}
				   				}
				   				break;
				   				
			    				case 2:
			    				//EL ENEMIGO SE MUEVE HACIA ARRIBA SOLO SI EXISTE (SI TIENE VIDA)
			    				//PRIMERO COMPRUEBA QUE AL MOVERSE NO SE SALGA DEL TABLERO NI ATRAVIESE PAREDES
					    		//DESPU�S VA COMPROBANDO POCO A POCO SI CHOCA CON OTROS ENEMIGOS, CON UN OBJETO O CON EL JUGADOR
			    				if ((dungeon[floorCurrent].enemies[i].getY() - 1) >= 0 && dungeon[floorCurrent].floor[dungeon[floorCurrent].enemies[i].getX()][(dungeon[floorCurrent].enemies[i].getY() - 1)].getCasilla() != 0) {
					    			int j = 0;
					    			while (j < Constants.getEnemies() && checkEnemy == null) {
					    				if (dungeon[floorCurrent].enemies[j].getX() == dungeon[floorCurrent].enemies[i].getX() && dungeon[floorCurrent].enemies[j].getY() == (dungeon[floorCurrent].enemies[i].getY() - 1)){
					    					checkEnemy = dungeon[floorCurrent].enemies[j];
					    					j++;
					    				}
					    				else {
					    					j++;
					    				}
					    			}
					    			if (checkEnemy != null) {
					    				//SI HAY OTRO ENEMIGO
					    				squareAvailability = false;	
					    			}
					    			else {
					    				//SI NO HAY OTRO ENEMIGO
					    				int k = 0;
					        			while (k < Constants.getObjects() && checkObject == null) {
					        				if (dungeon[floorCurrent].objects[k].getX() == dungeon[floorCurrent].enemies[i].getX() && dungeon[floorCurrent].objects[k].getY() == (dungeon[floorCurrent].enemies[i].getY() - 1)) {
					        					checkObject = dungeon[floorCurrent].objects[k];
					        					k++;
					        				}
					        				else {
					        					k++;
					        				}
					        			}
					        			if (checkObject != null) {
					        				//SI HAY UN OBJETO
					        				squareAvailability = false;
					        			}
					        			else {
					        				//SI NO HAY UN OBJETO
					        				if (xPlayer == dungeon[floorCurrent].enemies[i].getX() && yPlayer == (dungeon[floorCurrent].enemies[i].getY() - 1)) {
					        					//SI HAY JUGADOR, ATACA
					        					squareAvailability = false;
					        					player.setHealth(player.getHealth() - dungeon[floorCurrent].enemies[i].getDamage());
					        					minidungeon.md_setTextHealthCurrent(player.getHealth());
					        					minidungeon.md_animateDamage();
					       					}
					       					else {
					      						squareAvailability = true;
					     					}
					        			}
					        		}
					    			if (squareAvailability == true) {
					    				//SE MUEVE HACIA ARRIBA SI NO HAY JUGADOR
					    				minidungeon.md_moveSprite(dungeon[floorCurrent].enemies[i].getId(), dungeon[floorCurrent].enemies[i].getX(), dungeon[floorCurrent].enemies[i].getY() - 1);
					    			}
					   			}
					   			break;
					   			
			    				case 3:
			    				//EL ENEMIGO SE MUEVE HACIA ABAJO SOLO SI EXISTE (SI TIENE VIDA)
			    				//PRIMERO COMPRUEBA QUE AL MOVERSE NO SE SALGA DEL TABLERO NI ATRAVIESE PAREDES
						    	//DESPU�S VA COMPROBANDO POCO A POCO SI CHOCA CON OTROS ENEMIGOS, CON UN OBJETO O CON EL JUGADOR
			    				if ((dungeon[floorCurrent].enemies[i].getY() + 1) < Constants.getAlto() && dungeon[floorCurrent].floor[dungeon[floorCurrent].enemies[i].getX()][(dungeon[floorCurrent].enemies[i].getY() + 1)].getCasilla() != 0) {
						    		int j = 0;
						    		while (j < Constants.getEnemies() && checkEnemy == null) {
						    			if (dungeon[floorCurrent].enemies[j].getX() == dungeon[floorCurrent].enemies[i].getX() && dungeon[floorCurrent].enemies[j].getY() == (dungeon[floorCurrent].enemies[i].getY() + 1)){
						    				checkEnemy = dungeon[floorCurrent].enemies[j];
						    				j++;
						    			}
						    			else {
						    				j++;
						    			}
						    		}
						    		if (checkEnemy != null) {
						    			//SI HAY OTRO ENEMIGO
						    			squareAvailability = false;	
						    		}
						    		else {
						    			//SI NO HAY OTRO ENEMIGO
						    			int k = 0;
						        		while (k < Constants.getObjects() && checkObject == null) {
						        			if (dungeon[floorCurrent].objects[k].getX() == dungeon[floorCurrent].enemies[i].getX() && dungeon[floorCurrent].objects[k].getY() == (dungeon[floorCurrent].enemies[i].getY() + 1)) {
						        				checkObject = dungeon[floorCurrent].objects[k];
						        				k++;
						        			}
						        			else {
						        				k++;
						        			}
						        		}
						        		if (checkObject != null) {
						        			//SI HAY UN OBJETO
						        			squareAvailability = false;
						        		}
						        		else {
						        			//SI NO HAY UN OBJETO
						        			if (xPlayer == dungeon[floorCurrent].enemies[i].getX() && yPlayer == (dungeon[floorCurrent].enemies[i].getY() + 1)) {
						        				//SI HAY JUGADOR, ATACA
						        				squareAvailability = false;
						        				player.setHealth(player.getHealth() - dungeon[floorCurrent].enemies[i].getDamage());
						        				minidungeon.md_setTextHealthCurrent(player.getHealth());
						        				minidungeon.md_animateDamage();
						       				}
						       				else {
						       					//SI NO HAY JUGADOR
						      					squareAvailability = true;
						     				}
						        		}
						        	}
						    		if (squareAvailability == true) {
						    			//SE MUEVE HACIA ABAJO SI NO HAY JUGADOR
						    			minidungeon.md_moveSprite(dungeon[floorCurrent].enemies[i].getId(), dungeon[floorCurrent].enemies[i].getX(), dungeon[floorCurrent].enemies[i].getY() + 1);
						    		}
						   		}
						   		break;
			    			}
			    		}
			    	}
			    	
			    	
			    	//MOVIMIENTO DEL JUGADOR	    	
			    	String lastAction = minidungeon.md_getLastAction();
			    	switch (lastAction) {
			    		case "right":
			    		//PRIMERO COMPRUEBA QUE AL MOVERSE NO SE SALGA DEL TABLERO NI ATRAVIESE PAREDES
			    		if ((xPlayer + 1) < Constants.getAncho() && dungeon[floorCurrent].floor[xPlayer + 1][yPlayer].getCasilla() != 0) {
		    				//ATAQUE A ENEMIGO
		    				int i = 0;
		    				while (i < Constants.getEnemies() && checkEnemy == null) {
		    					if (dungeon[floorCurrent].enemies[i].getX() == (xPlayer + 1) && dungeon[floorCurrent].enemies[i].getY() == yPlayer && dungeon[floorCurrent].enemies[i].getHealth() != 0) {
		    						checkEnemy = dungeon[floorCurrent].enemies[i];
		    						i++;
		    					} else
		    						i++;
		    				}
		    				if (checkEnemy != null) {
		    					//SI HAY ENEMIGO VIVO
		    					freeSquare = false;
		    					player.setFood(player.getFood() - 2);
		    					//AL ATACAR PIERDE DOS UNIDADES DE COMIDA
		    					minidungeon.md_setTextFood(player.getFood());
		    					checkEnemy.setHealth(checkEnemy.getHealth() - player.getStrength());
		    					//SI LA VIDA DEL ENEMIGO ES 0, ESTE DESAPARECE
		    					if (checkEnemy.getHealth() <= 0) {
		    					    int bonesId = 1000;
		    					    //ID PARA COLOCAR LOS HUESOS AL MATAR AL ENEMIGO
		    						minidungeon.md_setSpriteVisible(checkEnemy.getId(), false);
		    						minidungeon.md_addSprite(bonesId, "bones.png", false);
		    						minidungeon.md_moveSprite(bonesId, checkEnemy.getX(), checkEnemy.getY());
		    						//SI SE QUIEREN COLOCAR LOS HUESOS (OPCIONAL), CAMBIAMOS EL SIGUIENTE FALSE POR UN TRUE
		    						minidungeon.md_setSpriteVisible(bonesId, false);
		    						bonesId++;
		    					}
		    				} else
		    					//SI NO HAY ENEMIGO O ESTE EST� MUERTO
		    					freeSquare = true;
		    					
		    				int j = 0;
		    				while (j < Constants.getObjects() && checkObject == null) {
		   						//COGER OBJETOS
		   						if (dungeon[floorCurrent].objects[j].getX() == (xPlayer + 1) && dungeon[floorCurrent].objects[j].getY() == yPlayer) {
		   							checkObject = dungeon[floorCurrent].objects[j];
		   							j++;
		    						switch (checkObject.getType()) {
		    						//LOS OBJETOS EST�N TODOS DECLARADOS EN LA CLASE OBJECT, AL IGUAL QUE SUS EFECTOS SOBRE EL JUGADOR (EN M�TODOS DENTRO DE ESA CLASE)
				    					case 0:
				   						//COMIDA
				   						player.Food();
				   						minidungeon.md_setTextFood(player.getFood());
			  							minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    					
				    					case 1:
				    					//ESPADA
				    					player.Sword();
				    					minidungeon.md_setTextStrength(player.getStrength());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    	
				    					case 2:
				    					//DINERO
				    					player.Gold();
				    					minidungeon.md_setTextGold(player.getGold());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    		
				    					case 3:
				    					//CORAZ�N
				    					player.Heart();
				    					minidungeon.md_setTextHealthCurrent(player.getHealth());
				    					minidungeon.md_setTextHealthMax(player.getHealthMax());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
										break;
				    			
				    					case 4:
				    					//ESCALERAS
				    					player.Stairs();
				    					floorCurrent++;
				    					minidungeon.md_setTextFloor(player.getFloor());
				    					//EL JUGADOR CAMBIA DE PISO, SE PINTA OTRO PISO
				    					dungeon[floorCurrent] = new Floor();
				    					pintarPiso(floorCurrent, minidungeon, dungeon);
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    					
				    					case 5:
				    					//POCI�N
				    					player.Potion();
				    					minidungeon.md_setTextHealthCurrent(player.getHealth());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
			    					}
		    					} else
		    						j++;
		    				}
		   					if (freeSquare == true) {
		   						//SI HAY UN OBJETO A LA DERECHA DEL JUGADOR O NO HAY NADA, EL JUGADOR PUEDE MOVERSE
		   						minidungeon.md_moveSprite(999, ++xPlayer, yPlayer);
		   						player.setFood((player.getFood() - 1));
		    					//AL MOVERSE PIERDE UNA UNIDAD DE COMIDA
		            			minidungeon.md_setTextFood(player.getFood());
		            			minidungeon.setVisible(true);
		            			if (player.getFood() == 0) {
		            				//SI LA COMIDA ES 0, LA FUERZA SE REDUCE A LA MITAD
		            				player.setStrength((player.getStrength() / 2));
		            				minidungeon.md_setTextStrength(player.getStrength());
		               				minidungeon.setVisible(true);
		            			}
		    				}
			   			}
			    		break;
							
			    		case "left":
			    		//PRIMERO COMPRUEBA QUE AL MOVERSE NO SE SALGA DEL TABLERO NI ATRAVIESE PAREDES
			    		if ((xPlayer - 1) >= 0 && dungeon[floorCurrent].floor[xPlayer - 1][yPlayer].getCasilla() != 0) {
		    				//ATAQUE A ENEMIGO
		    				int i = 0;
		    				while (i < Constants.getEnemies() && checkEnemy == null) {
		    					if (dungeon[floorCurrent].enemies[i].getX() == (xPlayer - 1) && dungeon[floorCurrent].enemies[i].getY() == yPlayer && dungeon[floorCurrent].enemies[i].getHealth() != 0) {
		    						checkEnemy = dungeon[floorCurrent].enemies[i];
		    						i++;
		    					} else
		    						i++;
		    				}
		    				if (checkEnemy != null) {
		    					//SI HAY ENEMIGO VIVO
		    					freeSquare = false;
		    					player.setFood(player.getFood() - 2);
		    					//AL ATACAR PIERDE DOS UNIDADES DE COMIDA
		    					minidungeon.md_setTextFood(player.getFood());
		    					checkEnemy.setHealth(checkEnemy.getHealth() - player.getStrength());
		    					//SI LA VIDA DEL ENEMIGO ES 0, ESTE DESAPARECE
		    					if (checkEnemy.getHealth() <= 0) {
		    						int bonesId = 1000;
		    					    //ID PARA COLOCAR LOS HUESOS AL MATAR AL ENEMIGO
		    						minidungeon.md_setSpriteVisible(checkEnemy.getId(), false);
		    						minidungeon.md_addSprite(bonesId, "bones.png", false);
		    						minidungeon.md_moveSprite(bonesId, checkEnemy.getX(), checkEnemy.getY());
		    						//SI SE QUIEREN COLOCAR LOS HUESOS (OPCIONAL), CAMBIAMOS EL SIGUIENTE FALSE POR UN TRUE
		    						minidungeon.md_setSpriteVisible(bonesId, false);
		    						bonesId++;
		    					}
		    				} else
		    					//SI NO HAY ENEMIGO O ESTE EST� MUERTO
		    					freeSquare = true;
		    				
		    				int j = 0;
		    				while (j < Constants.getObjects() && checkObject == null) {
		    					//COGER OBJETOS
		    					if (dungeon[floorCurrent].objects[j].getX() == (xPlayer - 1) && dungeon[floorCurrent].objects[j].getY() == yPlayer) {
		    						checkObject = dungeon[floorCurrent].objects[j];
		    						j++;
			    					switch (checkObject.getType()) {
			    					//LOS OBJETOS EST�N TODOS DECLARADOS EN LA CLASE OBJECT, AL IGUAL QUE SUS EFECTOS SOBRE EL JUGADOR (EN M�TODOS DENTRO DE ESA CLASE)
				    					case 0:
				    					//COMIDA
				    					player.Food();
				    					minidungeon.md_setTextFood(player.getFood());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    				
				    					case 1:
				    					//ESPADA
				    					player.Sword();
				    					minidungeon.md_setTextStrength(player.getStrength());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    				
				    					case 2:
				    					//DINERO
				    					player.Gold();
				    					minidungeon.md_setTextGold(player.getGold());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    					
				    					case 3:
				    					//CORAZ�N
				    					player.Heart();
				    					minidungeon.md_setTextHealthCurrent(player.getHealth());
				    					minidungeon.md_setTextHealthMax(player.getHealthMax());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    					
				    					case 4:
				    					//ESCALERAS
				    					player.Stairs();
				    					floorCurrent++;
				    					minidungeon.md_setTextFloor(player.getFloor());
				    					//EL JUGADOR CAMBIA DE PISO, SE PINTA OTRO PISO
				    					dungeon[floorCurrent] = new Floor();
				    					pintarPiso(floorCurrent, minidungeon, dungeon);
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), true);
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    					
				    					case 5:
				    					//POCI�N
				    					player.Potion();
				    					minidungeon.md_setTextHealthCurrent(player.getHealth());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
			    					}
		    					} else
		    						j++;
		    				}
		    				if (freeSquare == true) {
		    					//SI HAY UN OBJETO A LA IZQUIERDA DEL JUGADOR O NO HAY NADA, EL JUGADOR PUEDE MOVERSE
		    					minidungeon.md_moveSprite(999, --xPlayer, yPlayer);
		    					player.setFood((player.getFood() - 1));
		    					//AL MOVERSE PIERDE UNA UNIDAD DE COMIDA
		            			minidungeon.md_setTextFood(player.getFood());
		            			minidungeon.setVisible(true);
		            			if (player.getFood() == 0) {
		            				//SI LA COMIDA ES 0, LA FUERZA SE REDUCE A LA MITAD
		            				player.setStrength((player.getStrength() / 2));
		            				minidungeon.md_setTextStrength(player.getStrength());
		                			minidungeon.setVisible(true);
		            			}
		    				}
			    		}
						break;
			    			
			    		case "up":
			    		//PRIMERO COMPRUEBA QUE AL MOVERSE NO SE SALGA DEL TABLERO NI ATRAVIESE PAREDES
			    		if ((yPlayer - 1) >= 0 && dungeon[floorCurrent].floor[xPlayer][yPlayer - 1].getCasilla() != 0) {
		    				//ATAQUE A ENEMIGO
		    				int i = 0;
		    				while (i < Constants.getEnemies() && checkEnemy == null) {
		    					if (dungeon[floorCurrent].enemies[i].getX() == xPlayer && dungeon[floorCurrent].enemies[i].getY() == (yPlayer - 1) && dungeon[floorCurrent].enemies[i].getHealth() != 0) {
		    						checkEnemy = dungeon[floorCurrent].enemies[i];
		    						i++;
		    					} else
		    						i++;
		    				}
		    				if (checkEnemy != null) {
		    					//SI HAY ENEMIGO VIVO
		    					freeSquare = false;
		    					player.setFood(player.getFood() - 2);
		    					//AL ATACAR PIERDE DOS UNIDADES DE COMIDA
		    					minidungeon.md_setTextFood(player.getFood());
		    					checkEnemy.setHealth(checkEnemy.getHealth() - player.getStrength());
		    					//SI LA VIDA DEL ENEMIGO ES 0, ESTE DESAPARECE
		    					if (checkEnemy.getHealth() <= 0) {
		    						int bonesId = 1000;
			    				    //ID PARA COLOCAR LOS HUESOS AL MATAR AL ENEMIGO
		    						minidungeon.md_setSpriteVisible(checkEnemy.getId(), false);
		    						minidungeon.md_addSprite(bonesId, "bones.png", false);
		    						minidungeon.md_moveSprite(bonesId, checkEnemy.getX(), checkEnemy.getY());
		    						//SI SE QUIEREN COLOCAR LOS HUESOS (OPCIONAL), CAMBIAMOS EL SIGUIENTE FALSE POR UN TRUE
		    						minidungeon.md_setSpriteVisible(bonesId, false);
		    						bonesId++;
		    					}
		    				} else
		    					//SI NO HAY ENEMIGO O ESTE EST� MUERTO
		    					freeSquare = true;
		    					
		    				int j = 0;
		    				while (j < Constants.getObjects() && checkObject == null) {
		    					//COGER OBJETOS
		    					if (dungeon[floorCurrent].objects[j].getX() == xPlayer && dungeon[floorCurrent].objects[j].getY() == (yPlayer - 1)) {
		    						checkObject = dungeon[floorCurrent].objects[j];
		    						j++;
			    					switch (checkObject.getType()) {
			    					//LOS OBJETOS EST�N TODOS DECLARADOS EN LA CLASE OBJECT, AL IGUAL QUE SUS EFECTOS SOBRE EL JUGADOR (EN M�TODOS DENTRO DE ESA CLASE)
				    					case 0:
				    					//COMIDA
				   						player.Food();
				   						minidungeon.md_setTextFood(player.getFood());
				 						minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    				
				    					case 1:
				    					//ESPADA
				    					player.Sword();
				    					minidungeon.md_setTextStrength(player.getStrength());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    					
				    					case 2:
				    					//DINERO
				    					player.Gold();
				    					minidungeon.md_setTextGold(player.getGold());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    					
				    					case 3:
				    					//CORAZ�N
				    					player.Heart();
				    					minidungeon.md_setTextHealthCurrent(player.getHealth());
				    					minidungeon.md_setTextHealthMax(player.getHealthMax());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    						
				    					case 4:
				    					//ESCALERAS
				    					player.Stairs();
				    					floorCurrent++;
				    					minidungeon.md_setTextFloor(player.getFloor());
				    					//EL JUGADOR CAMBIA DE PISO, SE PINTA OTRO PISO
				    					dungeon[floorCurrent] = new Floor();
				    					pintarPiso(floorCurrent, minidungeon, dungeon);
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), true);
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    					
				    					case 5:
				    					//POCI�N
				    					player.Potion();
				    					minidungeon.md_setTextHealthCurrent(player.getHealth());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
			    					}
		    					} else
		    						j++;
		    				}
		    				if (freeSquare == true) {
		    					//SI HAY UN OBJETO ENCIMA DEL JUGADOR O NO HAY NADA, EL JUGADOR PUEDE MOVERSE
		    					minidungeon.md_moveSprite(999, xPlayer, --yPlayer);
		    					player.setFood((player.getFood() - 1));
		    					//AL MOVERSE PIERDE UNA UNIDAD DE COMIDA
		            			minidungeon.md_setTextFood(player.getFood());
		            			minidungeon.setVisible(true);
		            			if (player.getFood() == 0) {
		            				//SI LA COMIDA ES 0, LA FUERZA SE REDUCE A LA MITAD
		            				player.setStrength((player.getStrength() / 2));
		            				minidungeon.md_setTextStrength(player.getStrength());
		                			minidungeon.setVisible(true);
		            			}
		    				}
			    		}
						break;
			    			
			    		case "down":
			    		//PRIMERO COMPRUEBA QUE AL MOVERSE NO SE SALGA DEL TABLERO NI ATRAVIESE PAREDES
			    		if ((yPlayer + 1) < Constants.getAncho() && dungeon[floorCurrent].floor[xPlayer][yPlayer + 1].getCasilla() != 0) {
		    				//ATAQUE A ENEMIGO
		    				int i = 0;
		    				while (i < Constants.getEnemies() && checkEnemy == null) {
		    					if (dungeon[floorCurrent].enemies[i].getX() == xPlayer && dungeon[floorCurrent].enemies[i].getY() == (yPlayer + 1) && dungeon[floorCurrent].enemies[i].getHealth() != 0) {
		    						checkEnemy = dungeon[floorCurrent].enemies[i];
		    						i++;
		    					} else
		    						i++;
		    				}
		    				if (checkEnemy != null) {
		    					//SI HAY ENEMIGO VIVO
		    					freeSquare = false;
		    					player.setFood(player.getFood() - 2);
		    					//AL ATACAR PIERDE DOS UNIDADES DE COMIDA
		    					minidungeon.md_setTextFood(player.getFood());
		    					checkEnemy.setHealth(checkEnemy.getHealth() - player.getStrength());
		    					//SI LA VIDA DEL ENEMIGO ES 0, ESTE DESAPARECE
		    					if (checkEnemy.getHealth() <= 0) {
		    						int bonesId = 1000;
				    				//ID PARA COLOCAR LOS HUESOS AL MATAR AL ENEMIGO
		    						minidungeon.md_setSpriteVisible(checkEnemy.getId(), false);
		    						minidungeon.md_addSprite(bonesId, "bones.png", false);
		    						minidungeon.md_moveSprite(bonesId, checkEnemy.getX(), checkEnemy.getY());
		    						//SI SE QUIEREN COLOCAR LOS HUESOS (OPCIONAL), CAMBIAMOS EL SIGUIENTE FALSE POR UN TRUE
		    						minidungeon.md_setSpriteVisible(bonesId, false);
		    						bonesId++;
		    					}
		    				} else
		    					//SI NO HAY ENEMIGO O ESTE EST� MUERTO
		    					freeSquare = true;
		    				
		    				int j = 0;
		    				while (j < Constants.getObjects() && checkObject == null) {
		    					//COGER OBJETOS
		    					if (dungeon[floorCurrent].objects[j].getX() == xPlayer && dungeon[floorCurrent].objects[j].getY() == (yPlayer + 1)) {
		    						checkObject = dungeon[floorCurrent].objects[j];
		    						j++;
			    					switch (checkObject.getType()) {
			    					//LOS OBJETOS EST�N TODOS DECLARADOS EN LA CLASE OBJECT, AL IGUAL QUE SUS EFECTOS SOBRE EL JUGADOR (EN M�TODOS DENTRO DE ESA CLASE)
				    					case 0:
				    					//COMIDA
				    					player.Food();
				    					minidungeon.md_setTextFood(player.getFood());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    					
				    					case 1:
				    					//ESPADA
				    					player.Sword();
				    					minidungeon.md_setTextStrength(player.getStrength());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    						
				    					case 2:
				    					//DINERO
				    					player.Gold();
				    					minidungeon.md_setTextGold(player.getGold());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    					
				    					case 3:
				    					//CORAZ�N
				    					player.Heart();
				    					minidungeon.md_setTextHealthCurrent(player.getHealth());
				    					minidungeon.md_setTextHealthMax(player.getHealthMax());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    						
				    					case 4:
				    					//ESCALERAS
				    					player.Stairs();
				    					floorCurrent++;
				    					minidungeon.md_setTextFloor(player.getFloor());
				    					//EL JUGADOR CAMBIA DE PISO, SE PINTA OTRO PISO
				    					dungeon[floorCurrent] = new Floor();
				    					pintarPiso(floorCurrent, minidungeon, dungeon);
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), true);
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
				    					
				    					case 5:
				    					//POCI�N
				    					player.Potion();
				    					minidungeon.md_setTextHealthCurrent(player.getHealth());
				    					minidungeon.md_setSpriteVisible(checkObject.getId(), false);
				    					minidungeon.md_moveSprite(checkObject.getId(), Constants.getAncho(), Constants.getAlto());
				    					checkObject.setX(Constants.getAncho());
				    					checkObject.setY(Constants.getAlto());
				    					break;
			    					}
		    					}else
		    						j++;
		    				}
		    				if (freeSquare == true) {
		    					//SI HAY UN OBJETO DEBAJO DEL JUGADOR O NO HAY NADA, EL JUGADOR PUEDE MOVERSE
		    					minidungeon.md_moveSprite(999, xPlayer, ++yPlayer);
		    					player.setFood((player.getFood() - 1));
		    					//AL MOVERSE PIERDE UNA UNIDAD DE COMIDA
		            			minidungeon.md_setTextFood(player.getFood());
		            			minidungeon.setVisible(true);
		            			if (player.getFood() == 0) {
		            				//SI LA COMIDA ES 0, LA FUERZA SE REDUCE A LA MITAD
		            				player.setStrength((player.getStrength() / 2));
		            				minidungeon.md_setTextStrength(player.getStrength());
		                			minidungeon.setVisible(true);
		    					}
		    				}
			    		}
						break;
			    	}
			    	
			    	
			    	Thread.sleep(300);
			    	//VELOCIDAD TANTO LA DE LOS ENEMIGOS COMO LA DEL JUGADOR
			    	
			    	
			    	if (lastAction.equals("new game")) {
			    		newGame = false;
			    		//NUEVO JUEGO
			    	}
			    }
			}
		}
	}
}
