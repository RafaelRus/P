
public class Object {

	//CARACTER�STICAS DEL OBJETO
	private int id;
	private int type;
	private int x;
	private int y;
	private String spriteFileName;
	
	
	public Object(int id, int type) {
		//M�TODO PARA IDENTIFICAR EL TIPO DE OBJETO
		//CADA TIPO TENDR� UNA IMAGEN CARACTER�STICA
		this.id = id;
		this.type= type;
		switch(type) {
			case 0:
			//COMIDA
			setSpriteFileName("apple.png");
			break;
			
			case 1:
			//ESPADA
			setSpriteFileName("sword.png");
			break;
			
			case 2:
			//DINERO
			setSpriteFileName("gold.png");
			break;
			
			case 3:
			//CORAZ�N
			setSpriteFileName("heart.png");
			break;
			
			case 4:
			//ESCALERAS
			setSpriteFileName("stairs-up.png");
			break;
			
			case 5:
			//POCI�N
			setSpriteFileName("potion.png");
			break;
		}
	}
	
	
	public void print() {
		//IMPRIMIR LOS OBJETOS, SU ID Y SU TIPO (EN CASO DE QUE EL JUGADOR QUIERA SABER SU POSICI�N EXACTA)
		System.out.println("Object: " + id + ", " + x + ", " + y + ", " + type);
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	
	
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	
	public String getSpriteFileName() {
		return spriteFileName;
	}
	public void setSpriteFileName(String spriteFileName) {
		this.spriteFileName = spriteFileName;
	}
}
