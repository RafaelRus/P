
public class Square {
	
	private int casilla;
	private int red;
	private int green;
	private int blue;
	
	
	//DAR COLOR A LAS CASILLAS DEL TABLERO CON ESTE M�TODO
	public Square(int casilla) {
		this.setCasilla(casilla);
		switch (getCasilla()) {
			case 0:
			//PARED
			setRed(100);
			setGreen(100);
			setBlue(100);
			break;
			
			case 1:
			//PASILLO	
			setRed(255);
			setGreen(255);
			setBlue(255);
			break;
			
			case 2:
			//SALA	
			setRed(255);
			setGreen(255);
			setBlue(255);
			break;
		}
	}

	
	public int getCasilla() {
		return casilla;
	}
	public void setCasilla(int casilla) {
		this.casilla = casilla;
	}

	
	public int getRed() {
		return red;
	}
	public void setRed(int red) {
		this.red = red;
	}

	
	public int getGreen() {
		return green;
	}
	public void setGreen(int green) {
		this.green = green;
	}

	
	public int getBlue() {
		return blue;
	}
	public void setBlue(int blue) {
		this.blue = blue;
	}
}
