
public class Constants {
	
	//CONSTANTES EDITABLES
	
	
	//ALTURA DEL TABLERO
	private static final int ALTO = 50;
	//ANCHURA DEL TABLERO
	private static final int ANCHO = 50;
	//N�MERO DE PASILLOS
	private static final int PASILLOS = 100;
	//N�MERO DE HABITACIONES
	private static final int HABITACIONES = 6;
	//N�MERO DE PISOS
	private static final int PISOS = 100;
	//N�MERO DE ENEMIGOS
	private static final int ENEMIES = 10;
	//N�MERO DE OBJETOS
	private static final int OBJECTS = 30;
	
	
	public static int getAlto() {
		return ALTO;
	}

	
	public static int getAncho() {
		return ANCHO;
	}

	
	public static int getPasillos() {
		return PASILLOS;
	}
	
	
	public static int getHabitaciones() {
		return HABITACIONES;
	}
	
	
	public static int getPisos() {
		return PISOS;
	}

	
	public static int getEnemies() {
		return ENEMIES;
	}
	
	
	public static int getObjects() {
		return OBJECTS;
	}
}