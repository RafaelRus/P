
public class Player {
	
	//CARACTER�STICAS DEL JUGADOR
	private String name = "Player";
	private int food = 1000;
	private int strength = 1;
	private int gold = 0;
	private int health = 500;
	private int healthMax = 500;
	private int floor = 0;
		
	
	public void Food() {
		//LLAMAREMOS A ESTE M�TODO EN EL MAIN CADA VEZ QUE EL JUGADOR CONSIGA LA MANZANA
		setFood(getFood() + 20);
	}
	
	
	public void Sword() {
		//LLAMAREMOS A ESTE M�TODO EN EL MAIN CADA VEZ QUE EL JUGADOR CONSIGA LA ESPADA
		setStrength(getStrength() + 1);
	}
	
	
	public void Gold() {
		//LLAMAREMOS A ESTE M�TODO EN EL MAIN CADA VEZ QUE EL JUGADOR CONSIGA EL ORO
		setGold(getGold() + 10);
	}
	
	
	public void Heart() {
		//LLAMAREMOS A ESTE M�TODO EN EL MAIN CADA VEZ QUE EL JUGADOR CONSIGA EL CORAZ�N
		setHealthMax(getHealthMax() + 100);
		setHealth(getHealthMax());
	}
	
	
	public void Stairs() {
		//LLAMAREMOS A ESTE M�TODO EN EL MAIN CADA VEZ QUE EL JUGADOR SUBA LAS ESCALERAS
		setFloor(getFloor() + 1);
	}
	
	
	public void Potion() {
		////LLAMAREMOS A ESTE M�TODO EN EL MAIN CADA VEZ QUE EL JUGADOR CONSIGA LA POCI�N
		int counter = 0;
		while (counter <= 50 && getHealth() < getHealthMax()) {
			//ESTE WHILE HACE QUE LA VIDA ACTUAL NO SOBREPASE LA VIDA M�XIMA AL COGER LA POCI�N
			setHealth(getHealth() + counter);
			counter++;
		}
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public int getFood() {
		return food;
	}
	public void setFood(int food) {
		this.food = food;
	}
	
	
	public int getStrength() {
		return strength;
	}
	public void setStrength(int strength) {
		this.strength = strength;
	}
	
	
	public int getGold() {
		return gold;
	}
	public void setGold(int gold) {
		this.gold = gold;
	}

	
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		this.health = health;
	}

	
	public int getHealthMax() {
		return healthMax;
	}
	public void setHealthMax(int healthMax) {
		this.healthMax = healthMax;
	}

	
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}
}
