
public class Floor {
	
	//EN ESTA CLASE SE DECLARAN Y CREAN LOS ARRAYS DE CASILLAS, ENEMIGOS Y OBJETOS
	Square floor [][];
	Enemy enemies [];
	Object objects[];
	
	
	//IMPRIMIR LOS OBJETOS, SU ID Y SU TIPO (EN CASO DE QUE EL JUGADOR QUIERA SABER SU POSICI�N EXACTA)
	public void printObjects() {
		System.out.println(objects);
		for (int i = 0; i < objects.length; i++) {
			if (objects[i] != null) {
				objects[i].print();
			}
		}
	}
	
	
	//IMPRIMIR LOS ENEMIGOS, SU ID Y SU TIPO (EN CASO DE QUE EL JUGADOR QUIERA SABER SU POSICI�N EXACTA)
	public void printEnemies() {
		System.out.println(enemies);
		for (int i = 0; i < enemies.length; i++) {
			if (enemies[i] != null) {
				enemies[i].print();
			}
		}
	}
	
	
	private void CrearPasillo(int casillaX, int casillaY) {
		//M�TODO PARA CREAR SOLAMENTE UN PASILLO, EL PRIMER PASILLO
		//PREVIAMENTE, EN EL M�TODO FLOOR (COLOCADO M�S ABAJO), SE CREA LA CASILLA DE PARTIDA
		
		
		//CONTADOR DE CASILLAS
		int contadorCasillas = 0;
		//DIMENSI�N DEL PASILLO
		int dimPasillo = 0;
		//DIRECCI�N PROHIB�DA
		int forbbidenWay = 100;
		//N�MERO DE CASILLAS
		int nCasillas = 1000;
		//DIRECCI�N ALEATORIA
		int nAleatorio;
		
		
		while (contadorCasillas < nCasillas) {
			do {
				//PARA LA PROBABILIDAD DE LA DIRECCI�N ALEATORIA QUE TOMARA EL PRIMER PASILLO AL GENERARSE
				nAleatorio = (int) (Math.random() * 400);
				if (nAleatorio > 0 && nAleatorio <= 100) {
					nAleatorio = 0;
				}
				else if (nAleatorio > 25 && nAleatorio <= 200) {
					nAleatorio = 1;
				}
				else if (nAleatorio > 50 && nAleatorio <= 300) {
					nAleatorio = 2;
				}
				else {
					nAleatorio = 3;
				}
			} while (nAleatorio == forbbidenWay);
			
			
			switch (nAleatorio) {
				case 0:
				//SE GENERA UNA CASILLA A LA DERECHA
				forbbidenWay = 2;
				while (dimPasillo < ((int)(Math.random() * 30 + 3))) {
					if ((casillaX + 1) < Constants.getAncho() && (casillaX + 2) < Constants.getAncho() && (casillaY + 1) < Constants.getAlto() && (casillaY - 1) >= 0 && (casillaY + 2) < Constants.getAlto()) {
						if (floor [casillaX + 1][casillaY].getCasilla() != 1 && floor [casillaX + 2][casillaY].getCasilla() != 1 && floor [casillaX + 1][casillaY + 1].getCasilla() != 1 && floor [casillaX + 1][casillaY - 1].getCasilla() != 1) {
							floor [casillaX][casillaY] = new Square (1);
							casillaX++; 
						}
					}
					dimPasillo++;
				}
				dimPasillo = 0;
				break;
				
				case 1:
				//SE GENERA UNA CASILLA ABAJO
				forbbidenWay = 3;
				while (dimPasillo < ((int)(Math.random() * 30 + 3))) {
					if ((casillaY + 1) < Constants.getAlto() && (casillaX - 1) >= 0 && (casillaX + 1) < Constants.getAncho() && (casillaY + 2) < Constants.getAlto()) {
						if (floor [casillaX][casillaY + 1].getCasilla() != 1 && floor [casillaX][casillaY + 2].getCasilla() != 1 && floor [casillaX +1][casillaY + 1].getCasilla() != 1 && floor [casillaX - 1][casillaY + 1].getCasilla() != 1) {
							floor [casillaX][casillaY] = new Square (1);
							casillaY++; 
						}
					}
					dimPasillo++;
				}
				dimPasillo = 0;
				break;
				
				case 2:
				//SE GENERA UNA CASILLA A LA IZQUIERDA
				forbbidenWay = 0;
				while (dimPasillo < ((int)(Math.random() * 30 + 3))) {
					if ((casillaX - 1) >= 0 && (casillaY - 1) >= 0 && (casillaX - 2) >= 0 && (casillaY + 1) < Constants.getAlto()) {
						if (floor [casillaX - 1][casillaY].getCasilla() != 1 && floor [casillaX - 2][casillaY].getCasilla() != 1 && floor [casillaX - 1][casillaY + 1].getCasilla() != 1 && floor [casillaX - 1][casillaY - 1].getCasilla() != 1) {	
							floor [casillaX][casillaY] = new Square (1);
							casillaX--; 
						}
					}
					dimPasillo++;
				}
				dimPasillo = 0;
				break;
				
				case 3:
				//SE GENERA UNA CASILLA ARRIBA
				forbbidenWay = 1;
				while (dimPasillo < ((int)(Math.random() * 30 + 3))) {
					if ((casillaY - 1) >= 0 && (casillaX - 1) >= 0 && (casillaX + 1) < Constants.getAncho() && (casillaY - 2) >= 0) {
						if (floor [casillaX][casillaY - 1].getCasilla() != 1 && floor [casillaX][casillaY - 2].getCasilla() != 1 && floor [casillaX + 1][casillaY - 1].getCasilla() != 1 && floor [casillaX - 1][casillaY - 1].getCasilla() != 1) {	
							floor [casillaX][casillaY] = new Square (1);
							casillaY--; 
						}
					}
					dimPasillo++;
				}
				dimPasillo = 0;
				break;
			}
			contadorCasillas++;
		}
	}
	
	
	private void CrearSala() {
		//M�TODO PARA CREAR SOLAMENTE UNA SALA
		//LO QUE HACE ES CREAR LA SALA A PARTIR DE UNA CASILLA DEL MAPA QUE SEA YA PASILLO
		
		
		boolean squareValid = false;
		int roomX = 0, roomY = 0;
		while (!squareValid) {
			//WHILE PARA GENERAR LA PRIMERA CASILLA DE LA SALA
			roomX = (int) (Math.random() * Constants.getAncho());
			roomY = (int) (Math.random() * Constants.getAlto());
			if ((floor [roomX][roomY].getCasilla() == 1)) { 
				squareValid = true;
			}
		}
		
		
		//PARA GENERAR LA HABITACI�N CON EL TAMA�O ROOMWIDTH X ROOMHEIGHT
		int counterY = 0;
		int counterX = 0;
		int roomWidth = (int) (Math.random() * 4 + 3);
		int roomHeight = (int) (Math.random() * 4 + 3);
		while (counterY < roomWidth) {
			while (counterX < roomHeight) {
				if (roomX < Constants.getAncho() && roomY >= 0) {
				floor[roomX][roomY] = new Square(2);
				roomX++;
				}
				counterX++;
			}
			roomX -= counterX;
			roomY--;
			counterX = 0;
			counterY++;
		}
	}
	
	
	public Floor() {
		//PRIMERO SE GENERA EL ARRAY DE CASILLAS, CON LAS DIMENSIONES DEL TABLERO
		floor = new Square [Constants.getAlto()][Constants.getAncho()];
		for (int i = 0; i < floor.length; i++) {
			for (int j = 0; j < floor[i].length; j++) {
				floor [i][j] = new Square (0);	
			}
		}
		
		
		//CASILLA INICIAL ALEATORIA Y CREAR PASILLO A PARTIR DE ESA CASILLA
		int casillaX, casillaY;
		casillaX = (int) (Math.random() * Constants.getAncho()); 
		casillaY = (int) (Math.random() * Constants.getAlto());
		floor [casillaX][casillaY] = new Square (1);
		CrearPasillo(casillaX, casillaY);
		
		
		//CREAR PASILLOS CONECTADOS
		//PRIMERO SELECCIONA UNA CASILLA ALEATORIA, COMPRUEBA SI ES PASILLO Y SI ES PASILLO CREA UN NUEVO PASILLO A PARTIR DE ESA CASILLA
		int pasillos = 0;
		while (pasillos < Constants.getPasillos()) {
			boolean squareValid = false;
			int x = 0, y = 0;
			while (!squareValid) {
				x = (int) (Math.random() * Constants.getAncho());
				y = (int) (Math.random() * Constants.getAlto());
				if (floor[x][y].getCasilla() == 1) {
					squareValid = true;
				}
			}
			CrearPasillo(x, y);
			pasillos++;
		}
		
		
		//PARA CREAR HABITACIONES
		int habitaciones = 0;
		while (habitaciones < Constants.getHabitaciones()) {
			CrearSala();
			habitaciones++;
		}
		
		
		//GENERACI�N DE OBJETOS
		int nObjects = 0;
		int nSword = 0;
		int nHeart = 0;
		int nStairs = 0;
		
		
		System.out.println("GENERACI�N DE OBJETOS: ");
		objects = new Object[Constants.getObjects()];
		
		
		//EL ID INICIAL DE LOS OBJETOS
		int objectId = 101;
			
		
		while (nObjects < Constants.getObjects()) {
			//DENTRO DE ESTE WHILE SE DECLARA Y CREA EL ARRAY DE OBJETOS
			boolean squareValid = false;
			int xObject = 0;
			int yObject = 0;
			int randomType = (int)(Math.random() * 6);
			objects[nObjects] = new Object(objectId, randomType);
			switch (randomType) {
				case 0:
				//COMIDA
				while (squareValid == false) {
					//POSICI�N DE LA COMIDA
					xObject = (int) (Math.random() * Constants.getAncho());
					yObject = (int) (Math.random() * Constants.getAlto());
					
					
					for (int i = 0; i < objects.length; i++) {
						//COMPRUEBA QUE NO SE CREEN OBJETOS EN EL MISMO SITIO
						if (floor[xObject][yObject].getCasilla() != 0) {
							if (objects[i] != null) {
								if (objects[i].getX() == xObject && objects[i].getY() == yObject) {
									squareValid = false;
								}
								else {
									squareValid = true;
								}
							}
						}
					}
					if (squareValid == true) {
						objects[nObjects].setX(xObject);
						objects[nObjects].setY(yObject);
						objects[nObjects].setId(objectId);
						objectId++;
					}
				}
				nObjects++;
				break;
				
				case 1:
				//ESPADA, SOLO SE CREA 1 (POR ELLO SE UTILIZA UN IF)
				if (nSword < 1) {
					while (squareValid == false) {
						//POSICI�N DE LA ESPADA
						xObject = (int) (Math.random() * Constants.getAncho());
						yObject = (int) (Math.random() * Constants.getAlto());
							
						
						for (int i = 0; i < objects.length; i++) {
							//COMPRUEBA QUE NO SE CREEN OBJETOS EN EL MISMO SITIO
							if (floor[xObject][yObject].getCasilla() != 0) {
								if (objects[i] != null) {
									if (objects[i].getX() == xObject && objects[i].getY() == yObject) {
										squareValid = false;
									}
									else {
										squareValid = true;
									}
								}
							}
						}
						if (squareValid == true) {
							objects[nObjects].setX(xObject);
							objects[nObjects].setY(yObject);
							objects[nObjects].setId(objectId);
							objectId++;
							nSword++;
						}
					}
					nObjects++;
				}
				else {
					squareValid = false;
				}
				break;
				
				case 2:
				//DINERO
				while (squareValid == false) {
					//POSICI�N DEL DINERO
					xObject = (int) (Math.random() * Constants.getAncho());
					yObject = (int) (Math.random() * Constants.getAlto());
					
					
					for (int i = 0; i < objects.length; i++) {
						//COMPRUEBA QUE NO SE CREEN OBJETOS EN EL MISMO SITIO
						if (floor[xObject][yObject].getCasilla() != 0) {
							if (objects[i] != null) {
								if (objects[i].getX() == xObject && objects[i].getY() == yObject) {
									squareValid = false;
								}
								else {
									squareValid = true;
								}
							}
						}
					}
					if (squareValid == true) {
						objects[nObjects].setX(xObject);
						objects[nObjects].setY(yObject);
						objects[nObjects].setId(objectId);
						objectId++;
					}
				}
				nObjects++;
				break;	
				
				case 3:
				//CORAZ�N, SOLO SE CREA 1 (POR ELLO SE UTILIZA UN IF)
				if (nHeart < 1) {
					while (squareValid == false) {
						//POSICI�N DEL CORAZ�N
						xObject = (int) (Math.random() * Constants.getAncho());
						yObject = (int) (Math.random() * Constants.getAlto());
								
						
						for (int i = 0; i < objects.length; i++) {
							//COMPRUEBA QUE NO SE CREEN OBJETOS EN EL MISMO SITIO
							if (floor[xObject][yObject].getCasilla() != 0) {
								if (objects[i] != null) {
									if (objects[i].getX() == xObject && objects[i].getY() == yObject) {
										squareValid = false;
									}
									else {
										squareValid = true;
									}
								}
							}
						}
						if (squareValid == true) {
							objects[nObjects].setX(xObject);
							objects[nObjects].setY(yObject);
							objects[nObjects].setId(objectId);
							objectId++;
							nHeart++;
						}
					}
					nObjects++;
				}
				else {
					squareValid = false;
				}
				break;
				
				case 4:
				//ESCALERAS, SOLO SE CREA 1 (POR ELLO SE UTILIZA UN IF)
				if (nStairs < 1) {
					while (squareValid == false) {
						//POSICI�N DE LAS ESCALERAS
						xObject = (int) (Math.random() * Constants.getAncho());
						yObject = (int) (Math.random() * Constants.getAlto());
										
						
						for (int i = 0; i < objects.length; i++) {
							//COMPRUEBA QUE NO SE CREEN OBJETOS EN EL MISMO SITIO
							if (floor[xObject][yObject].getCasilla() == 2) {
								if (objects[i] != null) {
									if (objects[i].getX() == xObject && objects[i].getY() == yObject) {
										squareValid = false;
									}
									else {
										squareValid = true;
									}
								}
							}
						}
						if (squareValid == true) {
							objects[nObjects].setX(xObject);
							objects[nObjects].setY(yObject);
							objects[nObjects].setId(objectId);
							objectId++;
							nStairs++;
						}
					}
					nObjects++;
				}
				else {
					squareValid = false;
				}
				break;
						
				case 5:
				//POCI�N
				while (squareValid == false) {
					//POSICI�N DE LA POCI�N
					xObject = (int) (Math.random() * Constants.getAncho());
					yObject = (int) (Math.random() * Constants.getAlto());
							
					
					for (int i = 0; i < objects.length; i++) {
						//COMPRUEBA QUE NO SE CREEN OBJETOS EN EL MISMO SITIO
						if (floor[xObject][yObject].getCasilla() != 0) {
							if (objects[i] != null) {
								if (objects[i].getX() == xObject && objects[i].getY() == yObject) {
									squareValid = false;
								}
								else {
									squareValid = true;
								}
							}
						}
					}
					if (squareValid == true) {
						objects[nObjects].setX(xObject);
						objects[nObjects].setY(yObject);
						objects[nObjects].setId(objectId);
						objectId++;
					}
				}
				nObjects++;
				break;			
			}
		}
		//IMPRIMIR LOS OBJETOS
		printObjects();
		
		
		System.out.println("");
		
		
		//GENERACI�N DE ENEMIGOS
		int nEnemies = 0;
		int nFinalEnemy = 0;
		
		
		System.out.println("GenerationEnemies: ");
		enemies = new Enemy[Constants.getEnemies()];
		
		
		//EL ID INICIAL DE LOS ENEMIGOS
		int enemyId = 1;
		
		
		while (nEnemies < Constants.getEnemies()) {
			//DENTRO DE ESTE WHILE SE DECLARA Y CREA EL ARRAY DE ENEMIGOS
			boolean squareValid = false;
			int xEnemy = 0;
			int yEnemy = 0;
			int randomType = (int)(Math.random() * 4);
			enemies[nEnemies] = new Enemy(enemyId, randomType);
			switch (randomType) {
				case 0:
				//ENEMIGO 1
				while (squareValid == false) {
					//POSICI�N DEL ENEMIGO 1
					xEnemy = (int) (Math.random() * Constants.getAncho());
					yEnemy = (int) (Math.random() * Constants.getAlto());
						
					
					for (int i = 0; i < Constants.getObjects(); i++) {
						//COMPRUEBA QUE NO SE CREEN OBJETOS EN EL MISMO SITIO
						if (objects[i] != null) {
							if (objects[i].getX() == xEnemy && objects[i].getY() == yEnemy) {
								squareValid = false;
							}
							else {
								for (int j = 0; j < Constants.getEnemies(); j++) {
									//COMPRUEBA QUE NO SE CREEN ENEMIGOS EN EL MISMO SITIO
									if (floor[xEnemy][yEnemy].getCasilla() != 0) {
										if (enemies[j] != null) {
											if (enemies[j].getX() == xEnemy && enemies[j].getY() == yEnemy) {
												squareValid = false;										
											}
											else {
												squareValid = true;
											}
										}
									}
								}
							}
						}
					}
					if (squareValid == true) {
						enemies[nEnemies].setX(xEnemy);
						enemies[nEnemies].setY(yEnemy);
						enemies[nEnemies].setId(enemyId);
						enemyId++;
					}
				}
				nEnemies++;
				break;
				
				case 1:
				//ENEMIGO 2
				while (squareValid == false) {
					//POSICI�N DEL ENEMIGO 2
					xEnemy = (int) (Math.random() * Constants.getAncho());
					yEnemy = (int) (Math.random() * Constants.getAlto());
							
					
					for (int i = 0; i < Constants.getObjects(); i++) {
						//COMPRUEBA QUE NO SE CREEN OBJETOS EN EL MISMO SITIO
						if (objects[i] != null) {
							if (objects[i].getX() == xEnemy && objects[i].getY() == yEnemy) {
								squareValid = false;
							}
							else {
								for (int j = 0; j < Constants.getEnemies(); j++) {
									//COMPRUEBA QUE NO SE CREEN ENEMIGOS EN EL MISMO SITIO
									if (floor[xEnemy][yEnemy].getCasilla() != 0) {
										if (enemies[j] != null) {
											if (enemies[j].getX() == xEnemy && enemies[j].getY() == yEnemy) {
												squareValid = false;										
											}
											else {
												squareValid = true;
											}
										}
									}
								}
							}
						}
					}
					if (squareValid == true) {
						enemies[nEnemies].setX(xEnemy);
						enemies[nEnemies].setY(yEnemy);
						enemies[nEnemies].setId(enemyId);
						enemyId++;
					}
				}
				nEnemies++;
				break;
				
				case 2:
				//ENEMIGO 3
				while (squareValid == false) {
					//POSICI�N DEL ENEMIGO 3
					xEnemy = (int) (Math.random() * Constants.getAncho());
					yEnemy = (int) (Math.random() * Constants.getAlto());
							
					
					for (int i = 0; i < Constants.getObjects(); i++) {
						//COMPRUEBA QUE NO SE CREEN OBJETOS EN EL MISMO SITIO
						if (objects[i] != null) {
							if (objects[i].getX() == xEnemy && objects[i].getY() == yEnemy) {
								squareValid = false;
							}
							else {
								for (int j = 0; j < Constants.getEnemies(); j++) {
									//COMPRUEBA QUE NO SE CREEN ENEMIGOS EN EL MISMO SITIO
									if (floor[xEnemy][yEnemy].getCasilla() != 0) {
										if (enemies[j] != null) {
											if (enemies[j].getX() == xEnemy && enemies[j].getY() == yEnemy) {
												squareValid = false;										
											}
											else {
												squareValid = true;
											}
										}
									}
								}
							}
						}
					}
					if (squareValid == true) {
						enemies[nEnemies].setX(xEnemy);
						enemies[nEnemies].setY(yEnemy);
						enemies[nEnemies].setId(enemyId);
						enemyId++;
					}
				}
				nEnemies++;
				break;	
				
				case 3:
				//ENEMIGO FINAL, SOLO SE CREA 1 (POR ELLO SE UTILIZA UN IF)
				if (nFinalEnemy < 1) {
					while (squareValid == false) {
						//POSICI�N DEL ENEMIGO FINAL
						xEnemy = (int) (Math.random() * Constants.getAncho());
						yEnemy = (int) (Math.random() * Constants.getAlto());
						
						
						for (int i = 0; i < Constants.getObjects(); i++) {
							//COMPRUEBA QUE NO SE CREEN OBJETOS EN EL MISMO SITIO
							if (objects[i] != null) {
								if (objects[i].getX() == xEnemy && objects[i].getY() == yEnemy) {
									squareValid = false;
								}
								else {
									for (int j = 0; j < Constants.getEnemies(); j++) {
										//COMPRUEBA QUE NO SE CREEN ENEMIGOS EN EL MISMO SITIO
										if (floor[xEnemy][yEnemy].getCasilla() == 2) {
											if (enemies[j] != null) {
												if (enemies[j].getX() == xEnemy && enemies[j].getY() == yEnemy) {
													squareValid = false;										
												}
												else {
													squareValid = true;
												}
											}
										}
									}
								}
							}
						}
						if (squareValid == true) {
							enemies[nEnemies].setX(xEnemy);
							enemies[nEnemies].setY(yEnemy);
							enemies[nEnemies].setId(enemyId);
							enemyId++;
							nFinalEnemy++;
						}
					}
					nEnemies++;
				}
				else {
					squareValid = false;
				}
				break;	
			}
		}
		//IMPRIMIR LOS ENEMIGOS
		printEnemies();
	}
}
